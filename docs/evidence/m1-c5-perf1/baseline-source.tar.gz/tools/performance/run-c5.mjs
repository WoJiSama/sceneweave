import { chromium } from '@playwright/test'
import fs from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'
import { fileURLToPath } from 'node:url'
import { createServer } from 'node:http'
import { execFileSync, spawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import { unzipSync } from 'fflate'
import { copyArchivedFixtures } from './archived-fixtures.mjs'
import { closeMeasuredBrowser } from './close-browser.mjs'
import { startResourceSampling } from './resources.mjs'
import { installC5Observer } from './c5-observer.mjs'
import { summarizeC5 } from './summarize-c5.mjs'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..'), args = process.argv.slice(2)
if (args.includes('--help')) {
  console.log('node tools/performance/run-c5.mjs --output ABS --fixtures ABS [--dist ABS] [--cases study-500,study-2000,island-500,island-2000] [--runs 3] [--selections 30] [--edits 10] [--layers 10] [--appearances 5] [--restores 3] [--menus 10] [--gestures 3] [--wait-timeout-ms 60000] [--channel chrome] [--diagnostic] [--diagnostic-profile]')
  console.log('Normal production UI only. Empty independent output directory required. Run serially without other browser/test/build work. Reduced samples/matrix are diagnostic. --diagnostic-profile always excludes the run from formal evidence and records only the first ordinary-edit in each case/run at a 1000us CDP sampling interval. Continuous gestures contain 30 rAF-paced pointer moves or 20 rAF-paced wheel inputs. No GPU/presentation or full QA pass is inferred.')
  process.exit(0)
}
const argument = (name, fallback) => { const i = args.indexOf(name); return i < 0 ? fallback : args[i + 1] }
const output = argument('--output', null), fixtureDirectory = argument('--fixtures', null), dist = path.resolve(argument('--dist', path.join(root, 'dist')))
const channel = argument('--channel', 'chrome'), requestedCases = argument('--cases', 'study-500,study-2000,island-500,island-2000').split(',')
const diagnosticProfile = args.includes('--diagnostic-profile'), diagnostic = args.includes('--diagnostic') || diagnosticProfile
const waitTimeoutMs = Number(argument('--wait-timeout-ms', '60000'))
const counts = Object.fromEntries(Object.entries({ runs: 3, selections: 30, edits: 10, layers: 10, appearances: 5, restores: 3, menus: 10, gestures: 3 }).map(([key, value]) => [key, Number(argument(`--${key}`, String(value)))]))
const check = (condition, message) => { if (!condition) throw new Error(message) }, hash = bytes => createHash('sha256').update(bytes).digest('hex')
check(output && path.isAbsolute(output) && fixtureDirectory && path.isAbsolute(fixtureDirectory), '--output ABS and --fixtures ABS are required')
check(Object.values(counts).every(value => Number.isSafeInteger(value) && value > 0), 'Sample counts must be positive integers')
check(Number.isSafeInteger(waitTimeoutMs) && waitTimeoutMs > 0 && waitTimeoutMs <= 10 * 60_000, '--wait-timeout-ms must be a positive integer no greater than 600000')
check(requestedCases.length && new Set(requestedCases).size === requestedCases.length && requestedCases.every(name => /^(study|island)-(500|2000)$/.test(name)), 'Expected unique B5 case names')
const formal = !diagnostic && requestedCases.length === 4 && Object.entries({ runs: 3, selections: 30, edits: 10, layers: 10, appearances: 5, restores: 3, menus: 10, gestures: 3 }).every(([key, min]) => counts[key] >= min)
try { check((await fs.readdir(output)).length === 0, 'Output must be empty; existing evidence will not be overwritten') } catch (error) { if (error.code !== 'ENOENT') throw error }
await fs.mkdir(output, { recursive: true })
const writeJson = (name, value, exclusive = false) => fs.writeFile(path.join(output, name), JSON.stringify(value, null, 2), exclusive ? { flag: 'wx' } : undefined)
async function fingerprints(directory, relative = '') {
  const files = []
  for (const entry of await fs.readdir(path.join(directory, relative), { withFileTypes: true })) {
    const name = path.join(relative, entry.name)
    if (entry.isDirectory()) files.push(...await fingerprints(directory, name))
    else if (entry.isFile()) { const bytes = await fs.readFile(path.join(directory, name)); files.push({ path: name, sizeBytes: bytes.length, sha256: hash(bytes) }) }
  }
  return files.sort((a, b) => a.path.localeCompare(b.path))
}
const html = await fs.readFile(path.join(dist, 'index.html'), 'utf8')
check(!html.includes('/@vite/client'), 'Expected a normal production build')
const servedBase = /<script[^>]+src="([^"]+\/assets\/)/.exec(html)?.[1]?.replace(/assets\/$/, '') ?? '/'
const allowIncidentalFavicon404 = !/<link\b[^>]*\brel\s*=\s*["'][^"']*\bicon\b/i.test(html)
const runnerFiles = ['run-c5.mjs', 'c5-observer.mjs', 'summarize-c5.mjs', 'resources.mjs', 'archived-fixtures.mjs', 'close-browser.mjs']
const manifest = {
  format: 'sceneweave-c5-performance', version: 1, startedAt: new Date().toISOString(), status: 'running',
  measurementClass: diagnosticProfile ? 'diagnostic-c5-cpu-profile' : formal ? 'formal-c5-production-ui-observation' : 'diagnostic-c5-production-ui',
  sourceRevision: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
  sourceDirty: execFileSync('git', ['status', '--porcelain'], { cwd: root, encoding: 'utf8' }),
  runners: await Promise.all(runnerFiles.map(async name => { const bytes = await fs.readFile(path.join(root, 'tools/performance', name)); return { path: `tools/performance/${name}`, sizeBytes: bytes.length, sha256: hash(bytes) } })),
  node: process.version, device: { platform: os.platform(), release: os.release(), arch: os.arch(), cpu: os.cpus()[0]?.model, logicalCpus: os.cpus().length, memoryBytes: os.totalmem() },
  build: await fingerprints(dist),
  config: { ...counts, requestedCases, channel, diagnostic, diagnosticProfile, waitTimeoutMs, route: '#outdoor', viewport: { width: 1512, height: 982 }, dpr: 1,
    processState: 'Fresh dedicated headless Chrome process and profile per case/run; HTTP cache disabled, OS caches not purged. macOS caffeinate prevents idle sleep only.',
    fixturePreparation: 'Unmodified original B5 strict-v2 packages; native production UI validates, migrates through v3/v4/v5 to strict v6, and saves an independent copy. Two small user layers are added through UI; only the independent marker is moved to C5 Focus, keeping all measured member transactions within 256.',
    localReopen: 'Manual recent-project open. Preparation removes only the optional localStorage sceneweave.outdoorSceneId hint, reloads the normal page, opens the recent-project details if needed and verifies the native repository is unchanged. The timed interval starts at the trusted recent-project button click; reload and preparation are excluded.',
    intent: 'Trusted capture of the committing click, Enter keydown, file change, selection pointerup, contextmenu or first continuous input. The tool observes DOM/events; it never wraps product functions, Canvas, React or storage.',
    domainCommit: 'Exact page performance.now captured by WorkspaceV6 after all domain validation, identity/freeze/undo updates and before publish. DOM data-transaction-revision must match the new data-revision. Import/open/name are separate operations and do not claim a domain edit commit.',
    completion: 'DOM revision, Canvas base render counter with map aria-busy=false, local-save status and double-rAF are separate observations. A retained preview raster can be reused on adoption. Double-rAF is a scheduling proxy, never GPU or physical display completion.',
    continuousInputs: { panPointerMoves: 30, wheelInputs: 20, pacing: 'One requestAnimationFrame awaited before every Playwright input; input timestamps, gaps, trusted event counts, view state and frame intervals retained. Wheel is continuous positive deltaY=12. Fit reset is outside each measured gesture.' },
    networkAudit: { allowIncidentalFavicon404, policy: 'Retain every HTTP response URL/status, failed request, console error with source location and CDP browser log error. Only same-origin /favicon.ico with no query, status 404, no declared HTML icon, and a matching resource-load console/log source URL is incidental. All other HTTP errors and unexpected console/browser log errors fail the run. Canceled ERR_ABORTED requests are retained separately.' },
    cpuProfile: { enabled: diagnosticProfile, phase: 'first ordinary-edit only per case/run', samplingIntervalUs: 1000,
      boundary: 'CDP Profiler.start before the first ordinary-edit field fill/arm; stop after that sample has reached the same revision domain commit, DOM, Canvas ready, saved status and double-rAF proxy. Includes field preparation and automation/observer waits. Profile serialization is outside the sample; all profiled runs are diagnostic only.' },
    limits: ['Original fixtures retain their original extent/grid; this runner does not claim a 50 by 50 displayed grid.', 'RSS is sampled macOS dedicated-process-tree sum and can double-count shared pages; JS heap is target CDP metrics, not GPU or total physical memory.', 'Tooling audit phases include package downloads, readonly IndexedDB hashing and output verification. Their peaks are separated from product phases; phase-boundary samples remain raw.', 'Real UI operations are automated headless Chrome observations, not human UX, cross-browser, VTT import, or a complete QA-PERF-04 pass.', 'Formal runs use no CPU profiling. Optional diagnostic profiling adds overhead and is restricted to the first ordinary-edit; no tracing, forced GC, heap snapshot or source/dev API. Observer, automation, frame and resource polling overhead are included.', 'A Node wall gap above 5 seconds or browser wall/monotonic discontinuity above 250 ms invalidates the run. Slow renderer samples are retained.'],
  }, cases: [], results: [], failures: [], teardowns: [],
}
await writeJson('manifest.json', manifest)
const server = createServer(async (req, res) => {
  try {
    const requested = decodeURIComponent(new URL(req.url, 'http://localhost').pathname)
    const relative = (servedBase !== '/' && requested.startsWith(servedBase) ? requested.slice(servedBase.length - 1) : requested).replace(/^\//, '')
    const file = path.resolve(dist, relative || 'index.html')
    if (!file.startsWith(`${dist}${path.sep}`)) { res.writeHead(403); res.end(); return }
    const bytes = await fs.readFile(file), mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.json': 'application/json' }[path.extname(file)] ?? 'application/octet-stream'
    res.writeHead(200, { 'Content-Type': mime, 'Cache-Control': 'no-store' }); res.end(bytes)
  } catch { res.writeHead(404); res.end() }
})
await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve) })
const origin = `http://127.0.0.1:${server.address().port}`, pageUrl = `${origin}${servedBase}#outdoor`
const sleepGuard = process.platform === 'darwin' ? spawn('caffeinate', ['-i', '-w', String(process.pid)], { stdio: 'ignore' }) : null
sleepGuard?.on('error', () => {})
let browserServer = null, browser = null, page = null, sampler = null, result = null, label = null, interruption = null, lastPrintedKind = null
const listeners = new Set()
const interrupt = message => { if (!interruption) { interruption = new Error(message); for (const listener of listeners) listener(interruption) } }
let previousTick = Date.now()
const suspensionMonitor = setInterval(() => { const wall = Date.now(), gap = wall - previousTick; previousTick = wall; if (gap > 5000) interrupt(`Runner event loop wall gap ${gap}ms exceeds interruption limit`) }, 500)
suspensionMonitor.unref()
function guarded(promise) {
  return new Promise((resolve, reject) => {
    if (interruption) { void promise.catch(() => {}); reject(interruption); return }
    const fail = error => { listeners.delete(fail); reject(error) }; listeners.add(fail)
    void promise.then(value => { listeners.delete(fail); resolve(value) }, error => { listeners.delete(fail); reject(error) })
  })
}
const probe = () => page.evaluate(() => Reflect.get(window, '__sceneweaveC5Probe').snapshot())
const frames = () => page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))))
const nextFrame = () => page.evaluate(() => new Promise(requestAnimationFrame))
async function ready() {
  await page.waitForFunction(() => document.querySelector('.asset-save')?.textContent.trim() === '本地已保存' && document.querySelector('.asset-map-wrap')?.getAttribute('aria-busy') === 'false' && !document.querySelector('.asset-busy'))
  await page.locator('canvas[aria-label="材质场景主持人预览"],canvas[aria-label="材质场景玩家预览"]').waitFor({ state: 'visible' }); await frames()
}
async function refine() {
  const exposed = await page.locator('.asset-viewport').evaluate(node => node.hasAttribute('data-refinement-count'))
  if (exposed) await page.waitForFunction(() => {
    const node = document.querySelector('.asset-viewport'), detail = document.querySelector('.asset-detail-preview')
    return Number(node?.getAttribute('data-refinement-count')) > 0 && detail instanceof HTMLCanvasElement && detail.width > 0 && detail.height > 0 && getComputedStyle(detail).display !== 'none'
  })
  let previous = (await probe()).refinementCount
  for (let i = 0; i < 30; i++) {
    await page.waitForTimeout(320)
    const state = await probe()
    if (state.refinementCount === previous && state.mapBusy === 'false') return { refinementCount: state.refinementCount, stableForMs: 320, attempts: i + 1 }
    previous = state.refinementCount
  }
  throw new Error('Viewport refinement did not stabilize in setup')
}
async function measure(kind, ordinal, options, action) {
  if (interruption) throw interruption
  if (lastPrintedKind !== kind) { console.log(`C5 ${label}: ${kind} #${ordinal + 1}`); lastPrintedKind = kind }
  result.pendingAction = { kind, ordinal, armedAt: new Date().toISOString() }
  await page.evaluate(options => Reflect.get(window, '__sceneweaveC5Probe').arm(options), { kind, ordinal, ...options })
  await action()
  if (options.externalEnd) await page.evaluate(() => Reflect.get(window, '__sceneweaveC5Probe').endInputs())
  await page.waitForFunction(() => Reflect.get(window, '__sceneweaveC5Probe').read()?.complete, null, { timeout: waitTimeoutMs })
  const sample = await page.evaluate(() => Reflect.get(window, '__sceneweaveC5Probe').read())
  check(sample.intent?.trusted, `${kind}: missing trusted intent event`)
  check(sample.events.every(event => event.trusted), `${kind}: untrusted input in measured scope`)
  sample.intentToHandlerBubbleMs = sample.handlerBubbleMs === undefined ? null : sample.handlerBubbleMs - sample.intent.captureMs
  sample.intentToDomainCommitMs = sample.domainCommittedAtMs === undefined ? null : sample.domainCommittedAtMs - sample.intent.captureMs
  sample.intentToDomRevisionMs = sample.domRevisionMs === undefined ? null : sample.domRevisionMs - sample.intent.captureMs
  sample.intentToRasterReadyMs = sample.rasterReadyMs === undefined ? null : sample.rasterReadyMs - sample.intent.captureMs
  sample.intentToSavedMs = sample.savedReadyMs === undefined ? null : sample.savedReadyMs - sample.intent.captureMs
  sample.intentToDomReadyMs = sample.domReadyMs - sample.intent.captureMs
  sample.intentToDisplayProxyMs = sample.displayProxyMs - sample.intent.captureMs
  sample.domainCommitToDomRevisionMs = sample.domRevisionMs === undefined || sample.domainCommittedAtMs === undefined ? null : sample.domRevisionMs - sample.domainCommittedAtMs
  sample.browserClockDiscontinuityMs = (sample.clockAtDisplay.wallMs - sample.clockAtArm.wallMs) - (sample.clockAtDisplay.monotonicMs - sample.clockAtArm.monotonicMs)
  check(Math.abs(sample.browserClockDiscontinuityMs) <= 250, `${kind}: browser clocks diverged, possible host suspension`)
  if (options.domainCommit) check(sample.domainCommittedAtMs >= sample.intent.captureMs && sample.after.transactionRevision === sample.expectedRevision && sample.after.revision === sample.expectedRevision, `${kind}: exact transaction timestamp/revision mismatch`)
  if (options.unchangedDocument) check(sample.before.revision === sample.after.revision && sample.before.save === sample.after.save, `${kind}: transient UI changed document/save state`)
  const end = sample.endInput?.captureMs ?? sample.externalEndMs ?? sample.displayProxyMs
  sample.activeInputFrameGapMs = sample.frameIntervals.filter(entry => entry.startMs >= sample.intent.captureMs && entry.endMs <= end).map(entry => entry.durationMs)
  sample.frameGapMs = sample.frameIntervals.map(entry => entry.durationMs)
  result.samples.push(sample); delete result.pendingAction
  return sample
}
const buttonStart = name => ({ event: 'click', selector: 'button', button: 0, label: name })
async function transaction(kind, ordinal, action, { requireRaster = false, ...rest } = {}) {
  const before = await probe()
  return measure(kind, ordinal, { start: { event: 'click', selector: 'button', button: 0 }, expectedRevision: before.revision + 1,
    domainCommit: true, requireSaved: true, requireRaster, ...rest }, action)
}
const canvasBox = () => page.getByLabel('材质场景主持人预览', { exact: true }).boundingBox()
const screenPoint = (box, bounds, point) => ({ x: box.x + (point.x - bounds.x) / bounds.width * box.width, y: box.y + (point.y - bounds.y) / bounds.height * box.height })
async function markerClick(item) {
  const box = await canvasBox(); check(box?.width > 0, 'Missing visible map canvas')
  const point = screenPoint(box, item.summary.worldBoundsMm, item.summary.selectionPointMm)
  await page.mouse.click(point.x, point.y)
}
async function marquee(item) {
  const box = await canvasBox(), bounds = item.summary.worldBoundsMm
  const first = screenPoint(box, bounds, { x: bounds.x + 100, y: bounds.y + 100 }), last = screenPoint(box, bounds, { x: bounds.x + bounds.width - 100, y: bounds.y + bounds.height - 100 })
  await page.mouse.move(first.x, first.y); await page.mouse.down()
  for (let i = 1; i <= 8; i++) { await nextFrame(); await page.mouse.move(first.x + (last.x - first.x) * i / 8, first.y + (last.y - first.y) * i / 8) }
  await page.mouse.up()
}
function expectedProps(scene, bounds) {
  const left = bounds.x + 100, right = bounds.x + bounds.width - 100, top = bounds.y + 100, bottom = bounds.y + bounds.height - 100
  return Object.values(scene.props).filter(prop => {
    if (prop.editLocked || [...Object.values(scene.prefabInstances), ...Object.values(scene.scatterGroups)].some(group => group.editLocked && Object.values(group.members).some(member => member.propId === prop.id))) return false
    const v = prop.visualBoundsMm, a = prop.rotationDeg * Math.PI / 180, c = Math.cos(a), s = Math.sin(a)
    return [[v.x, v.y], [v.x + v.width, v.y], [v.x + v.width, v.y + v.height], [v.x, v.y + v.height]].every(([x, y]) => {
      const px = prop.positionMm.x + x * c - y * s, py = prop.positionMm.y + x * s + y * c
      return px >= left && px <= right && py >= top && py <= bottom
    })
  }).map(prop => prop.id).sort()
}
async function storageAudit({ includeResources = true } = {}) {
  return page.evaluate(async ({ includeResources }) => {
    const digest = async bytes => [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(value => value.toString(16).padStart(2, '0')).join('')
    const normalize = async value => {
      if (value instanceof Blob) return { blob: { bytes: value.size, type: value.type, sha256: await digest(await value.arrayBuffer()) } }
      if (value instanceof ArrayBuffer || ArrayBuffer.isView(value)) { const bytes = value instanceof ArrayBuffer ? value : value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength); return { bytes: bytes.byteLength, sha256: await digest(bytes) } }
      if (Array.isArray(value)) return Promise.all(value.map(normalize))
      if (value && typeof value === 'object') return Object.fromEntries(await Promise.all(Object.keys(value).sort().map(async key => [key, await normalize(value[key])])))
      return value
    }
    const databases = await indexedDB.databases(), entry = databases.find(item => item.name === 'sceneweave-m1-outdoor')
    if (!entry) throw new Error('No native v6 repository')
    const db = await new Promise((resolve, reject) => { const request = indexedDB.open(entry.name); request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error) })
    const rows = {}, stores = []
    try {
      for (const name of [...db.objectStoreNames].sort()) {
        if (!includeResources && ['assetBlobs', 'licenseTexts', 'migrationSources'].includes(name)) continue
        const data = await new Promise((resolve, reject) => {
          const transaction = db.transaction(name, 'readonly'), store = transaction.objectStore(name), keys = store.getAllKeys(), values = store.getAll()
          transaction.oncomplete = () => resolve({ keys: keys.result, values: values.result }); transaction.onerror = () => reject(transaction.error); transaction.onabort = () => reject(transaction.error)
        })
        rows[name] = data.values
        stores.push({ name, count: data.keys.length, sha256: await digest(new TextEncoder().encode(JSON.stringify(await normalize(data)))) })
      }
    } finally { db.close() }
    return { database: entry.name, version: entry.version, stores,
      scenes: (rows.scenes ?? []).map(row => ({ sceneId: row.sceneId, revision: row.revision, contentHash: row.contentHash, documentSchemaVersion: row.documentSchemaVersion, identityVersion: row.historyIdentity.version,
        propCount: Object.keys(row.document.props).length, title: row.document.title, grid: row.document.grid, worldBoundsMm: row.document.exportBoundsMm,
        props: row.document.props, userLayers: row.document.userLayers, entityLayers: row.document.entityLayers })),
      named: (rows.namedSnapshots ?? []).map(row => ({ id: row.id, name: row.name, sourceRevision: row.sourceRevision, contentHash: row.contentHash })),
      protection: (rows.protectionSnapshots ?? []).map(row => ({ id: row.id, sourceRevision: row.sourceRevision, contentHash: row.contentHash })), metadata: rows.historyMetadata ?? [] }
  }, { includeResources })
}
function packageSnapshot(bytes) {
  const files = unzipSync(bytes), parse = name => files[name] ? JSON.parse(new TextDecoder().decode(files[name])) : null
  const container = parse('manifest.json'), scene = parse('scene.json'), identity = parse('identity.json')
  return { containerVersion: container.containerVersion, documentSchemaVersion: scene.schemaVersion, sceneId: scene.sceneId, revision: scene.revision, identityVersion: identity?.version ?? null,
    propCount: Object.keys(scene.props).length, entries: Object.entries(files).filter(([name]) => name !== 'manifest.json').map(([name, value]) => ({ path: name, sizeBytes: value.length, sha256: hash(value) })).sort((a, b) => a.path.localeCompare(b.path)) }
}
async function backup(name) {
  const pending = page.waitForEvent('download')
  await page.getByRole('button', { name: '完整工程', exact: true }).click()
  const download = await pending; await download.saveAs(path.join(output, name)); await ready()
  const bytes = await fs.readFile(path.join(output, name))
  return { path: name, sizeBytes: bytes.length, sha256: hash(bytes), snapshot: packageSnapshot(bytes) }
}
async function plainEdit(item, kind, ordinal, value) {
  const field = page.getByLabel('物件 X', { exact: true })
  await field.fill(String(value))
  const before = await probe()
  const sample = await measure(kind, ordinal, { start: { event: 'keydown', selector: 'input[aria-label="物件 X"]', key: 'Enter' }, expectedRevision: before.revision + 1, domainCommit: true, requireRaster: true, requireSaved: true }, () => field.press('Enter'))
  sample.request = { id: item.summary.editablePropId, property: 'positionMm.x', value }
  return sample
}
async function profileFirstOrdinaryEdit(cdp, item, value) {
  const window = { kind: 'ordinary-edit', ordinal: 0, status: 'running', samplingIntervalUs: 1000, startedAt: new Date().toISOString(),
    boundary: manifest.config.cpuProfile.boundary }
  result.diagnosticProfiles.push(window)
  await cdp.send('Profiler.enable'); await cdp.send('Profiler.setSamplingInterval', { interval: 1000 }); await cdp.send('Profiler.start')
  window.pageAfterStartAtMs = await page.evaluate(() => performance.now())
  let sample, editError = null
  try {
    sample = await plainEdit(item, 'ordinary-edit', 0, value)
    sample.diagnosticCpuProfile = true
    window.intentAtPageMs = sample.intent.captureMs; window.domainCommittedAtPageMs = sample.domainCommittedAtMs
    window.displayProxyAtPageMs = sample.displayProxyMs
  } catch (error) { editError = error; window.editFailure = String(error); throw error }
  finally {
    try {
      window.pageBeforeStopAtMs = await page.evaluate(() => performance.now())
      const captured = await cdp.send('Profiler.stop')
      window.finishedAt = new Date().toISOString(); window.status = editError ? 'partial-edit-failure' : 'complete'
      window.profileStartTime = captured.profile.startTime; window.profileEndTime = captured.profile.endTime
      window.nodeCount = captured.profile.nodes.length; window.sampleCount = captured.profile.samples?.length ?? 0
      const name = `${label}-ordinary-edit-1.cpuprofile`, bytes = Buffer.from(JSON.stringify(captured.profile))
      sampler.setPhase('tooling-audit-cpu-profile')
      await fs.writeFile(path.join(output, name), bytes, { flag: 'wx' })
      window.artifact = { path: name, sizeBytes: bytes.length, sha256: hash(bytes) }
    } catch (error) {
      window.status = 'profile-collection-failed'; window.profileFailure = String(error)
      if (!editError) throw error
    } finally { await cdp.send('Profiler.disable').catch(() => {}) }
  }
  return sample
}
function reviewNetworkEvidence(ownedResult) {
  const incidentalFaviconUrl = value => {
    try { const url = new URL(value); return allowIncidentalFavicon404 && url.origin === origin && url.pathname === '/favicon.ico' && url.search === '' }
    catch { return false }
  }
  const favicon404 = response => response.status === 404 && incidentalFaviconUrl(response.url)
  const responses = [...ownedResult.httpResponses.map(response => ({ ...response, observer: 'playwright-page' })), ...ownedResult.cdpNetworkResponses.map(response => ({ ...response, observer: 'target-cdp' }))]
  const knownFavicon404 = url => incidentalFaviconUrl(url) && responses.some(response => favicon404(response) && response.url === url)
  const incidentalFaviconError = entry => knownFavicon404(entry.url ?? entry.location?.url) && /Failed to load resource/.test(entry.text) && /\b404\b/.test(entry.text)
  const errors = responses.filter(response => response.status >= 400)
  return { policy: manifest.config.networkAudit, pageResponseCount: ownedResult.httpResponses.length, cdpResponseCount: ownedResult.cdpNetworkResponses.length,
    responseObserverNote: 'Playwright suppresses favicon request/response page events. Target CDP Network.responseReceived is retained separately so the actual favicon URL/status remains auditable. The two observers can report the same product response; these counts are not unique requests.',
    incidentalFavicon404Responses: errors.filter(favicon404), productHttpErrors: errors.filter(response => !favicon404(response)),
    incidentalFaviconConsoleErrors: ownedResult.consoleErrorEvents.filter(incidentalFaviconError), unexpectedConsoleErrors: ownedResult.consoleErrorEvents.filter(entry => !incidentalFaviconError(entry)),
    incidentalFaviconBrowserLogErrors: ownedResult.browserLogErrors.filter(incidentalFaviconError), unexpectedBrowserLogErrors: ownedResult.browserLogErrors.filter(entry => !incidentalFaviconError(entry)),
    canceledRequests: ownedResult.requestFailures.filter(entry => entry.failure === 'net::ERR_ABORTED'),
    unexpectedRequestFailures: ownedResult.requestFailures.filter(entry => entry.failure !== 'net::ERR_ABORTED'),
  }
}
async function closeBrowser() {
  if (sampler) { const resources = await sampler.stop(); sampler = null; if (result) { result.resources = { path: `${label}-resources.json`, summary: resources.summary }; await writeJson(result.resources.path, resources, true) } }
  const teardown = await closeMeasuredBrowser(browserServer, browser)
  if (teardown) manifest.teardowns.push({ case: label, ...teardown })
  browserServer = null; browser = null; page = null
}
async function failureEvidence() {
  const evidence = { pendingAction: result?.pendingAction ?? null, probe: null, dom: null, screenshot: null, errors: [] }
  if (page && !page.isClosed()) {
    const bounded = promise => Promise.race([promise, new Promise((_, reject) => { const timer = setTimeout(() => reject(new Error('Failure collection timeout')), 2500); timer.unref() })])
    try { evidence.probe = await bounded(page.evaluate(() => Reflect.get(window, '__sceneweaveC5Probe')?.read() ?? null)) } catch (error) { evidence.errors.push(String(error)) }
    try { evidence.dom = await bounded(page.evaluate(() => ({ text: document.body.innerText.slice(-14000), hash: location.hash, visibility: document.visibilityState }))) } catch (error) { evidence.errors.push(String(error)) }
    try { evidence.screenshot = `${label}-failure.png`; await bounded(page.screenshot({ path: path.join(output, evidence.screenshot), timeout: 2000 })) } catch (error) { evidence.errors.push(String(error)) }
  }
  return evidence
}

async function runCase(item, run) {
  label = `${item.name}-run-${run}`
  lastPrintedKind = null
  result = { case: item.name, run, startedAt: new Date().toISOString(), samples: [], errors: [], pageErrorEvents: [], consoleErrors: [], consoleErrorEvents: [],
    httpResponses: [], cdpNetworkResponses: [], requestFailures: [], browserLogErrors: [], diagnosticProfiles: [], correctness: {}, auditArtifacts: [] }
  console.log(`C5 production UI ${label}`)
  const archived = unzipSync(await fs.readFile(path.join(output, item.artifact.path))), sourceScene = JSON.parse(new TextDecoder().decode(archived['scene.json']))
  browserServer = await chromium.launchServer({ channel, headless: true }); browser = await chromium.connect(browserServer.wsEndpoint())
  const context = await browser.newContext({ viewport: manifest.config.viewport, deviceScaleFactor: 1, acceptDownloads: true })
  await context.addInitScript(installC5Observer)
  page = await context.newPage(); page.setDefaultTimeout(60_000)
  const ownedResult = result
  page.on('pageerror', error => { ownedResult.errors.push(error.message); ownedResult.pageErrorEvents.push({ at: new Date().toISOString(), name: error.name, message: error.message, stack: error.stack }) })
  page.on('console', message => {
    if (message.type() === 'error') { ownedResult.consoleErrors.push(message.text()); ownedResult.consoleErrorEvents.push({ at: new Date().toISOString(), text: message.text(), location: message.location() }) }
  })
  page.on('response', response => ownedResult.httpResponses.push({ at: new Date().toISOString(), url: response.url(), status: response.status(), resourceType: response.request().resourceType(), method: response.request().method() }))
  page.on('requestfailed', request => ownedResult.requestFailures.push({ at: new Date().toISOString(), url: request.url(), resourceType: request.resourceType(), method: request.method(), failure: request.failure()?.errorText ?? null }))
  const cdp = await context.newCDPSession(page)
  cdp.on('Network.responseReceived', event => ownedResult.cdpNetworkResponses.push({ at: new Date().toISOString(), url: event.response.url, status: event.response.status, resourceType: event.type, requestId: event.requestId, timestamp: event.timestamp }))
  cdp.on('Log.entryAdded', ({ entry }) => { if (entry.level === 'error') ownedResult.browserLogErrors.push({ source: entry.source, text: entry.text, url: entry.url ?? null, timestamp: entry.timestamp, networkRequestId: entry.networkRequestId ?? null }) })
  await cdp.send('Log.enable'); await cdp.send('Performance.enable'); await cdp.send('Network.enable'); await cdp.send('Network.setCacheDisabled', { cacheDisabled: true })
  sampler = startResourceSampling({ rootPid: browserServer.process().pid, cdp, intervalMs: 100, heapIntervalMs: 200 })
  result.browser = browser.version()
  sampler.setPhase('cold-page-navigation')
  const navigationStart = performance.now(); await page.goto(pageUrl); await page.getByTestId('outdoor-workbench').waitFor({ state: 'visible' })
  result.coldPageNavigationMs = performance.now() - navigationStart
  check(await page.evaluate(() => Object.getOwnPropertyNames(window).filter(name => name.startsWith('__sceneweave') && name !== '__sceneweaveC5Probe').length === 0), 'Normal build exposed a product dev/performance API')
  sampler.setPhase('cold-package-prepare')
  await measure('cold-package-prepare', 0, { start: { event: 'change', selector: 'input[aria-label="选择完整室外工程"]' }, until: { visible: '[role="dialog"][aria-label="确认打开室外工程"]' } }, () => page.getByLabel('选择完整室外工程', { exact: true }).setInputFiles(path.join(output, item.artifact.path)))
  sampler.setPhase('cold-import-save-raster')
  await measure('cold-import-save-raster', 0, { start: buttonStart('保存并打开副本'), requireSaved: true, until: { absent: '[role="dialog"][aria-label="确认打开室外工程"]' } }, () => page.getByRole('button', { name: '保存并打开副本', exact: true }).click())
  await ready()
  sampler.setPhase('tooling-audit-import')
  const imported = await storageAudit(); result.auditArtifacts.push({ kind: 'import-storage', path: `${label}-import-storage.json` }); await writeJson(`${label}-import-storage.json`, imported, true)
  check(imported.scenes.length === 1 && imported.scenes[0].documentSchemaVersion === 3 && imported.scenes[0].identityVersion === 3 && imported.scenes[0].propCount === item.summary.propCount, 'Strict native v6 migration/import counts failed')
  result.sceneId = imported.scenes[0].sceneId; result.title = imported.scenes[0].title; result.correctness.nativeV6 = true
  sampler.setPhase('tooling-audit-local-reopen-preparation')
  result.localReopenPreparation = { startedAt: new Date().toISOString(), preference: await page.evaluate(() => {
    const key = 'sceneweave.outdoorSceneId', previousValue = localStorage.getItem(key)
    localStorage.removeItem(key)
    return { key, previousValue, valueAfterRemoval: localStorage.getItem(key) }
  }), method: 'Remove only the optional last-opened-scene localStorage hint; keep every native IndexedDB record and the complete saved project.' }
  sampler.setPhase('local-reopen-navigation-setup')
  const reloadStarted = performance.now()
  await page.reload(); await page.getByTestId('outdoor-workbench').waitFor({ state: 'visible' })
  await page.waitForFunction(() => !document.querySelector('[data-testid="outdoor-workbench"]')?.hasAttribute('data-revision') && !document.querySelector('.asset-busy'))
  const recentDetails = page.locator('details.asset-recents')
  if (!await recentDetails.evaluate(node => node.open)) await recentDetails.locator('summary').click()
  const recentButton = page.locator('.asset-recent button')
  await recentButton.waitFor({ state: 'visible' }); check(await recentButton.count() === 1 && await recentButton.isEnabled(), 'Expected one available manual recent-project button')
  result.localReopenPreparation.reloadToRecentUiMs = performance.now() - reloadStarted
  sampler.setPhase('tooling-audit-local-reopen-preparation')
  const preparedStorage = await storageAudit()
  check(JSON.stringify(preparedStorage) === JSON.stringify(imported), 'Manual reopen preparation changed the native repository')
  result.localReopenPreparation.nativeRepositoryUnchanged = true
  result.localReopenPreparation.finishedAt = new Date().toISOString()
  sampler.setPhase('local-reopen')
  const reopened = await measure('local-reopen', 0, { start: { event: 'click', selector: '.asset-recent button' }, expectedRevision: imported.scenes[0].revision, requireSaved: true }, () => recentButton.click())
  reopened.boundary = 'Trusted click of the visible enabled recent-project button after the normal empty page is ready; optional preference removal, reload, details expansion and repository audit are outside this sample.'
  await ready()
  sampler.setPhase('selection-setup')
  await page.getByRole('checkbox', { name: '选择组合成员', exact: true }).check(); await refine()
  await marquee(item); await frames()
  const broadIds = JSON.parse((await probe()).selection), expected = expectedProps(sourceScene, item.summary.worldBoundsMm)
  check(JSON.stringify(broadIds.filter(id => Object.hasOwn(sourceScene.props, id)).sort()) === JSON.stringify(expected), 'Selection prop membership differs from rotated visual corners/locks')
  check(expected.length > 256 && await page.getByRole('button', { name: '预览批量移动', exact: true }).isDisabled(), 'Over-budget bulk operation was not rejected')
  await markerClick(item); await frames(); check((await probe()).selection === JSON.stringify([item.summary.editablePropId]), 'Unexpected marker selection')
  for (let i = 0; i < 3; i++) { await marquee(item); await frames(); await markerClick(item); await frames() }
  result.selectionCalibration = { broadIds, independentlyExpectedPropIds: expected, markerId: item.summary.editablePropId }; result.selectionRefinementSetup = await refine()
  sampler.setPhase('tooling-audit-selection-before')
  const beforeSelectionStorage = await storageAudit(), beforeSelectionPackage = await backup(`${label}-selection-before.sceneweave`)
  await ready(); await refine()
  const selectionStart = await probe()
  sampler.setPhase('selection')
  for (let i = 0; i < counts.selections; i++) {
    for (const [kind, ids, action] of [['marquee', broadIds, () => marquee(item)], ['replacement', [item.summary.editablePropId], () => markerClick(item)]]) {
      const sample = await measure(kind, i, { start: { event: 'pointerup', selector: '.asset-viewport', button: 0 }, eventScope: '.asset-viewport', until: { selection: JSON.stringify(ids),
        text: kind === 'marquee' ? { selector: '.asset-inspector h3', value: `已选择 ${ids.length} 个对象` } : { selector: '.asset-inspector h2', value: '物件属性' } }, unchangedDocument: true }, action)
      check(sample.before.renderCount === sample.after.renderCount && sample.before.refinementCount === sample.after.refinementCount && sample.after.refinementCount === selectionStart.refinementCount, `${kind}: selection rerasterized or overlapped refinement`)
      if (kind === 'marquee') check(sample.eventCounts.pointermove === 9, 'Expected initial positioning plus eight rAF-paced marquee moves')
    }
  }
  sampler.setPhase('tooling-audit-selection-after')
  const afterSelectionStorage = await storageAudit(), afterSelectionPackage = await backup(`${label}-selection-after.sceneweave`)
  check(JSON.stringify(beforeSelectionStorage) === JSON.stringify(afterSelectionStorage), 'Selection changed persisted repository')
  check(JSON.stringify(beforeSelectionPackage.snapshot) === JSON.stringify(afterSelectionPackage.snapshot), 'Selection changed complete native package')
  result.correctness.selectionUnchanged = true; result.selectionPackages = { before: beforeSelectionPackage, after: afterSelectionPackage }
  sampler.setPhase('context-menu')
  const markerBox = await canvasBox(), marker = screenPoint(markerBox, item.summary.worldBoundsMm, item.summary.selectionPointMm)
  for (let i = 0; i < counts.menus; i++) {
    const keyboard = i % 2 === 1
    if (keyboard) await page.locator('.asset-viewport').focus()
    await measure(keyboard ? 'keyboard-menu' : 'pointer-menu', i, { start: keyboard ? { event: 'keydown', selector: '.asset-viewport', key: 'F10' } : { event: 'contextmenu', selector: '.asset-viewport' }, until: { menu: true }, unchangedDocument: true },
      () => keyboard ? page.locator('.asset-viewport').press('Shift+F10') : page.mouse.click(marker.x, marker.y, { button: 'right' }))
    await measure('menu-dismiss', i, { start: { event: 'keydown', selector: '[role="menu"]', key: 'Escape' }, until: { menu: false }, unchangedDocument: true }, () => page.keyboard.press('Escape'))
    check(await page.locator('.asset-viewport').evaluate(node => document.activeElement === node), 'Context menu did not restore viewport focus')
  }
  // The minimum diagnostic still exercises both input paths as correctness checks.
  if (counts.menus === 1) {
    await page.locator('.asset-viewport').focus(); await page.locator('.asset-viewport').press('Shift+F10'); await page.getByRole('menu').waitFor(); await page.keyboard.press('Escape')
  }
  result.correctness.pointerAndKeyboardMenus = true
  sampler.setPhase('continuous-viewport')
  for (let i = 0; i < counts.gestures; i++) {
    await page.getByRole('button', { name: '适应全图', exact: true }).click(); await refine()
    await page.getByRole('button', { name: '平移地图', exact: true }).click()
    const box = await page.locator('.asset-viewport').boundingBox(), start = { x: box.x + box.width * .4, y: box.y + box.height * .45 }
    await page.mouse.move(start.x, start.y)
    const pan = await measure('continuous-pan', i, { start: { event: 'pointerdown', selector: '.asset-viewport', button: 0 }, eventScope: '.asset-viewport', endEvent: { event: 'pointerup', selector: '.asset-viewport', button: 0 }, until: { viewChanged: true }, unchangedDocument: true }, async () => {
      await page.mouse.down()
      for (let move = 1; move <= 30; move++) { await nextFrame(); await page.mouse.move(start.x + move * 3, start.y + move) }
      await page.mouse.up()
    })
    check(pan.eventCounts.pointermove === 30, 'Continuous pan requires exactly 30 real pointer moves')
    await page.getByRole('button', { name: '适应全图', exact: true }).click(); await refine()
    await page.getByRole('button', { name: '选择地图对象', exact: true }).click()
    const canvas = await canvasBox(); await page.mouse.move(canvas.x + canvas.width / 2, canvas.y + canvas.height / 2)
    const wheel = await measure('continuous-wheel', i, { start: { event: 'wheel', selector: '.asset-viewport' }, eventScope: '.asset-viewport', externalEnd: true, until: { viewChanged: true }, unchangedDocument: true }, async () => {
      for (let step = 0; step < 20; step++) { await nextFrame(); await page.mouse.wheel(0, 12) }
    })
    check(wheel.eventCounts.wheel === 20, 'Continuous zoom requires exactly 20 real wheel events')
  }
  sampler.setPhase('viewport-reset-setup')
  await page.getByRole('button', { name: '适应全图', exact: true }).click(); await refine(); await markerClick(item); await frames()
  sampler.setPhase('ordinary-edit')
  const x = item.summary.selectionPointMm.x
  for (let i = 0; i < counts.edits; i++) {
    if (diagnosticProfile && i === 0) { sampler.setPhase('diagnostic-profile-ordinary-edit'); await profileFirstOrdinaryEdit(cdp, item, x + 100) }
    else { sampler.setPhase('ordinary-edit'); await plainEdit(item, 'ordinary-edit', i, i % 2 === 0 ? x + 100 : x) }
  }
  // Return marker to its documented click point before the remaining UI setup.
  if (counts.edits % 2) { sampler.setPhase('edit-reset-setup'); await plainEdit(item, 'edit-reset-setup', 0, x) }
  sampler.setPhase('layer-setup')
  const layerIds = {}
  for (const name of ['C5 Focus', 'C5 Spare']) {
    await page.getByRole('button', { name: '新建用户图层', exact: true }).click(); await page.getByLabel('新图层名称', { exact: true }).fill(name)
    await transaction('layer-create-setup', Object.keys(layerIds).length, () => page.getByRole('button', { name: '创建图层', exact: true }).click())
    layerIds[name] = await page.getByRole('button', { name: `设为当前图层 ${name}`, exact: true }).locator('..').locator('..').getAttribute('data-layer-id')
    check(layerIds[name], `No stable layer ID for ${name}`)
  }
  await page.getByRole('button', { name: /^移动所选到图层/ }).click(); await page.getByLabel('图层操作目标', { exact: true }).selectOption(layerIds['C5 Focus'])
  await measure('layer-move-preview', 0, { start: buttonStart('预览图层修改'), until: { preview: true }, unchangedDocument: true }, () => page.getByRole('button', { name: '预览图层修改', exact: true }).click())
  const moveScope = (await page.getByLabel('待采用图层操作 ID', { exact: true }).inputValue()).split('\n')
  check(moveScope.length <= 256 && moveScope.includes(item.summary.editablePropId), 'Small-layer member migration exceeded scope budget')
  await transaction('layer-move-adopt', 0, () => page.getByRole('button', { name: '采用图层修改', exact: true }).click(), { until: { preview: false } })
  await page.getByRole('button', { name: '设为当前图层 C5 Focus', exact: true }).click()
  result.layerSetup = { ids: layerIds, movedIds: moveScope }
  sampler.setPhase('layer-hide')
  for (let i = 0; i < counts.layers; i++) {
    const hide = i % 2 === 0, before = await probe()
    const sample = await measure('layer-hide', i, { start: buttonStart(hide ? '隐藏图层 C5 Focus' : '显示图层 C5 Focus'), requireRaster: true, requireSaved: true, unchangedDocument: true },
      () => page.getByRole('button', { name: `${hide ? '隐藏' : '显示'}图层 C5 Focus`, exact: true }).click())
    check(sample.after.hiddenLayerIds.includes(layerIds['C5 Focus']) === hide && sample.before.revision === before.revision, 'Unexpected transient layer visibility')
  }
  if (counts.layers % 2) { await page.getByRole('button', { name: '显示图层 C5 Focus', exact: true }).click(); await ready() }
  sampler.setPhase('layer-reorder')
  for (let i = 0; i < counts.layers; i++) {
    const up = page.getByRole('button', { name: '上移图层 C5 Focus', exact: true }), direction = await up.isEnabled() ? '上移' : '下移'
    const sample = await transaction('layer-reorder', i, () => page.getByRole('button', { name: `${direction}图层 C5 Focus`, exact: true }).click())
    check(JSON.stringify(sample.before.layerOrder) !== JSON.stringify(sample.after.layerOrder), 'Layer order failed to change')
  }
  sampler.setPhase('appearance-setup')
  await page.getByRole('button', { name: '选择图层成员 C5 Focus', exact: true }).click(); await frames()
  check(JSON.parse((await probe()).selection).length <= 256, 'Measured appearance scope exceeds 256')
  const appearance = page.getByRole('region', { name: '非破坏性外观', exact: true })
  await appearance.getByLabel('外观调整范围', { exact: true }).selectOption('layer'); await appearance.getByLabel('外观调整项目', { exact: true }).selectOption('brightness')
  sampler.setPhase('appearance')
  for (let i = 0; i < counts.appearances; i++) {
    await appearance.getByLabel('外观亮度', { exact: true }).fill(i % 2 === 0 ? '0.9' : '1')
    await measure('appearance-preview', i, { start: buttonStart('预览外观调整'), until: { preview: true }, unchangedDocument: true, requireRaster: true }, () => appearance.getByRole('button', { name: '预览外观调整', exact: true }).click())
    await transaction('appearance-adopt', i, () => page.getByRole('button', { name: '采用组件修改', exact: true }).click(), { until: { preview: false } })
  }
  sampler.setPhase('named-snapshot')
  const snapshotName = `C5 ${item.name} ${run}`
  await page.getByRole('tab', { name: '历史', exact: true }).click(); await page.getByRole('button', { name: '新建命名快照', exact: true }).click(); await page.getByLabel('命名快照名称', { exact: true }).fill(snapshotName)
  await measure('named-snapshot', 0, { start: buttonStart('保存快照'), until: { visible: '.history-snapshot-row.selected', absent: 'input[aria-label="命名快照名称"]' }, requireSaved: true, unchangedDocument: true }, () => page.getByRole('button', { name: '保存快照', exact: true }).click())
  sampler.setPhase('tooling-audit-history-before')
  const beforeHistory = await storageAudit({ includeResources: false })
  result.historyBefore = { named: beforeHistory.named, protection: beforeHistory.protection, metadata: beforeHistory.metadata }
  for (let i = 0; i < counts.restores; i++) {
    sampler.setPhase('restore-change-setup')
    await page.getByRole('tab', { name: '场景', exact: true }).click(); await markerClick(item); await frames()
    await plainEdit(item, 'restore-change-setup', i, x + 100)
    await page.getByRole('tab', { name: '历史', exact: true }).click()
    // Loading the named snapshot through the repository remains a distinct UI phase.
    sampler.setPhase('history-open')
    await measure('history-open', i, { start: buttonStart(`查看快照 ${snapshotName}`), until: { visible: 'select[aria-label="局部恢复模式"]' }, requireSaved: true, unchangedDocument: true }, () => page.getByRole('button', { name: `查看快照 ${snapshotName}`, exact: true }).click())
    await page.getByLabel('局部恢复模式', { exact: true }).selectOption('transform'); await page.getByLabel('搜索历史物件', { exact: true }).fill(item.summary.editablePropId)
    await page.getByRole('checkbox', { name: `恢复物件 ${item.summary.editablePropId}`, exact: true }).check()
    sampler.setPhase('restore-preview')
    await measure('restore-preview', i, { start: buttonStart('预览局部恢复'), until: { visible: '[aria-label="局部恢复候选"]' }, requireRaster: true, unchangedDocument: true }, () => page.getByRole('button', { name: '预览局部恢复 · 1 件', exact: true }).click())
    const affected = (await page.getByLabel('局部恢复完整实际范围', { exact: true }).inputValue()).split('\n')
    check(affected.length <= 256 && affected.includes(item.summary.editablePropId), 'Restore preview scope is invalid')
    await page.getByRole('checkbox', { name: '确认恢复完整影响范围', exact: true }).check()
    sampler.setPhase('restore-protect-adopt-save')
    const restored = await transaction('restore-protect-adopt-save', i, () => page.getByRole('button', { name: '保护当前并采用', exact: true }).click(), { until: { absent: '[aria-label="局部恢复候选"]' } })
    restored.affectedIds = affected
  }
  sampler.setPhase('tooling-audit-history-after')
  const afterHistory = await storageAudit({ includeResources: false })
  result.historyAfter = { named: afterHistory.named, protection: afterHistory.protection, metadata: afterHistory.metadata }
  check(afterHistory.protection.length === beforeHistory.protection.length + counts.restores, 'Protection checkpoint count mismatch')
  check(afterHistory.scenes[0].props[item.summary.editablePropId].positionMm.x === x, 'Local transform restore failed')
  result.correctness.namedAndProtection = true
  sampler.setPhase('export-4k-gm')
  const exports = []
  for (const audience of ['gm', 'player']) {
    if (audience === 'player') { sampler.setPhase('player-preview'); await page.getByRole('group', { name: '预览受众', exact: true }).getByRole('button', { name: '玩家', exact: true }).click(); await ready(); sampler.setPhase('export-4k-player') }
    const pending = page.waitForEvent('download')
    let capturedDownload = null
    const sample = await measure(`export-4k-${audience}`, 0, { start: buttonStart('4K PNG'), externalEnd: true, requireSaved: true, unchangedDocument: true }, async () => {
      await page.getByRole('button', { name: '4K PNG', exact: true }).click()
      const download = await pending, name = `${label}-${audience}-4096.png`
      const at = await page.evaluate(() => performance.now())
      capturedDownload = download
      exports.push({ audience, path: name, downloadObservedAtPageMs: at })
    })
    const file = exports.at(-1); file.intentToDownloadObservedMs = file.downloadObservedAtPageMs - sample.intent.captureMs
    sampler.setPhase('tooling-audit-export-retention')
    await capturedDownload.saveAs(path.join(output, file.path))
  }
  sampler.setPhase('tooling-audit-final')
  for (const artifact of exports) {
    const bytes = await fs.readFile(path.join(output, artifact.path)); check(bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])), 'Expected PNG signature')
    artifact.sizeBytes = bytes.length; artifact.sha256 = hash(bytes); artifact.width = bytes.readUInt32BE(16); artifact.height = bytes.readUInt32BE(20)
    check(Math.max(artifact.width, artifact.height) === 4096, 'Expected 4096px export long edge')
  }
  result.exports = exports
  await page.getByRole('group', { name: '预览受众', exact: true }).getByRole('button', { name: '主持人', exact: true }).click(); await ready()
  result.finalPackage = await backup(`${label}-final.sceneweave`)
  check(result.finalPackage.snapshot.containerVersion === 6 && result.finalPackage.snapshot.identityVersion === 3, 'Export lost strict v6 identity')
  const finalStorage = await storageAudit(); await writeJson(`${label}-final-storage.json`, finalStorage, true); result.auditArtifacts.push({ kind: 'final-storage', path: `${label}-final-storage.json` })
  result.networkAudit = reviewNetworkEvidence(result)
  check(!result.errors.length, 'Product emitted page errors')
  check(!result.networkAudit.productHttpErrors.length && !result.networkAudit.unexpectedRequestFailures.length, 'Product resource requests failed; inspect retained URLs/statuses')
  check(!result.networkAudit.unexpectedConsoleErrors.length && !result.networkAudit.unexpectedBrowserLogErrors.length, 'Product emitted unexpected console/browser log errors; inspect source URLs and network audit')
  result.correctness.networkErrorsReviewed = true
  result.finishedAt = new Date().toISOString()
  await closeBrowser()
  await writeJson(`${label}.json`, result, true)
  manifest.results.push({ case: item.name, run, path: `${label}.json`, resourcePath: result.resources.path }); await writeJson('manifest.json', manifest)
  console.log(`Completed ${label}: ${result.samples.length} observations`)
  result = null; label = null
}

try {
  check(process.platform === 'darwin', 'C5 RSS sampler currently requires macOS; unsupported platforms must not produce formal evidence')
  const copied = await copyArchivedFixtures({ sourceDirectory: fixtureDirectory, outputDirectory: output, requestedCases })
  manifest.cases = copied.cases; manifest.fixtureSource = copied.provenance; await writeJson('manifest.json', manifest)
  for (const item of manifest.cases) for (let run = 1; run <= counts.runs; run++) {
    const watchdog = setTimeout(() => interrupt('Dedicated case/run exceeded the 15 minute runner watchdog'), 15 * 60_000)
    try { await guarded(runCase(item, run)) } finally { clearTimeout(watchdog) }
  }
  check(JSON.stringify(await fingerprints(dist)) === JSON.stringify(manifest.build), 'Production dist changed during measurement')
  manifest.buildUnchangedAfterMeasurement = true; manifest.status = 'complete'; manifest.finishedAt = new Date().toISOString()
  await writeJson('manifest.json', manifest)
  const completed = await Promise.all(manifest.results.map(item => fs.readFile(path.join(output, item.path), 'utf8').then(JSON.parse)))
  await writeJson('summary.json', summarizeC5(manifest, completed), true)
} catch (error) {
  manifest.status = 'failed'; manifest.failures.push({ at: new Date().toISOString(), case: label, message: String(error), stack: error.stack }); process.exitCode = 1; console.error(error)
  if (result) { result.failure = manifest.failures.at(-1); result.failureEvidence = await failureEvidence() }
} finally {
  clearInterval(suspensionMonitor)
  try { await closeBrowser() } catch (error) { manifest.failures.push({ phase: 'teardown', message: String(error) }); manifest.status = 'failed'; process.exitCode = 1 }
  if (result) await writeJson(`${label}-partial-failure.json`, result, true)
  await writeJson('manifest.json', manifest); await new Promise(resolve => server.close(resolve)); sleepGuard?.kill()
}
