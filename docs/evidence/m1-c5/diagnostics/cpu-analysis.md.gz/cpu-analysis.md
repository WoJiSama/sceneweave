# C5 diagnostic 3：普通编辑 CPU 采样分析

本报告只分析已有的 study-500/run-1 首次 ordinary-edit。诊断完成，但启用了 CPU profiler，**不能作为正式性能通过证据**，也不覆盖 2000 件负载。未启动浏览器、测试或构建；只生成本报告及 [机器可读分析](cpu-analysis.json)。

## 结论

普通改坐标的主要延迟已发生在领域提交之前；完整场景解析、预算扫描、外观一致性和旧迁移原件校验存在重复工作。领域提交后还有明显的存储记录校验与保存等待。第一轮优化应复用内部严格解析并持有的不可变内容，减少连续完整校验；保留外部输入、实际资源、许可、迁移原件、CAS 与历史保护检查。

## 同页精确时序

以下全部来自同一 page performance.now，无需 CDP 时钟换算。

| 区间 | 观测值 |
|---|---:|
| 意图 capture → 领域提交 | 2464.6 ms |
| 领域提交 → DOM 新修订可见 | 89.1 ms |
| 领域提交 → 底图就绪 | 136.5 ms |
| 底图就绪 → 保存状态就绪 | 1369.5 ms |
| 领域提交 → 保存状态就绪 | 1506.0 ms |
| 保存状态就绪 → double-rAF | 64.1 ms |
| 意图 capture → double-rAF | 4034.7 ms |

底图就绪使用真实 Canvas 计数与 aria-busy=false；保存使用 UI 状态观测；double-rAF 是调度代理。这些不是 GPU、物理显示完成或独立磁盘 I/O 计时。

## 采样归属

以各窗口的 sampled timeDelta 权重为分母。每个家族内部取样本并集；**不同行 inclusive/家族存在嵌套，不能相加**。例如外观校验内可含严格场景解析，迁移导入内可含 JSON 扫描与 ZIP；下表不是互斥的 CPU 百分比分摊。

| 已识别家族 | 意图 → 领域（2464.6 ms） | 领域 → 显示代理（1570.1 ms） | 完整 profile（4182.2 ms 采样权重） |
|---|---:|---:|---:|
| 严格 v2/v3 场景解析（含依赖/几何） | 751.9 ms / 30.5% | 540.8 ms / 34.4% | 1292.7 ms / 30.9% |
| bounded JSON 解析 | 352.5 ms / 14.3% | 166.1 ms / 10.6% | 518.7 ms / 12.4% |
| 已识别完整包/候选预算 | 82.7 ms / 3.4% | 33.2 ms / 2.1% | 115.9 ms / 2.8% |
| 外观 resolve（含内部复制） | 43.3 ms / 1.8% | 43.7 ms / 2.8% | 87.1 ms / 2.1% |
| v5/v6 外观内容/draft 校验 | 414.5 ms / 16.8% | 396.9 ms / 25.3% | 811.4 ms / 19.4% |
| 已识别 v5/v6 身份校验 | 267.3 ms / 10.8% | 231.3 ms / 14.7% | 498.6 ms / 11.9% |
| 可见迁移原件导入/迁移验证栈 | 808.9 ms / 32.8% | 394.8 ms / 25.1% | 1203.7 ms / 28.8% |
| ZIP 读取/解压/CRC | 343.7 ms / 13.9% | 154.7 ms / 9.9% | 498.3 ms / 11.9% |
| 迁移导入可见栈与 ZIP 读取/解压/CRC 的并集 | 1081.1 ms / 43.9% | 518.9 ms / 33.0% | 1600.0 ms / 38.3% |
| v2/v4/v5 旧版完整工程校验 | 563.1 ms / 22.8% | 299.8 ms / 19.1% | 862.8 ms / 20.6% |
| 存储记录 assertScene/assertContent | 0.0 ms / 0.0% | 347.7 ms / 22.1% | 347.7 ms / 8.3% |

validateSceneV3 单函数 inclusive 为：领域前 634.0 ms、领域后 492.1 ms。完整 profile 里该函数下出现 49 个调用树节点，**不是 49 次调用**。JSON 中保存不同可见父调用上下文、self/inclusive 排行及家族重叠。

## 可识别的实际路径

- v6 prepare/materialize/apply/complete validation：构建内的 $o、Es、wo、Os、Ot、Pn 分别可映射到 prepareCompositionCommandsV6、materializeProjectV6、applyCompositionCommandsV6、validateCapturedProject、validateCompositionContentV6、validateCompositionDraftV6。
- v6 迁移原件验证 Vn 读取 original 字节并做 SHA，再 importProjectV5（Hs/xt）；previousSource 继续 v5/v4/v3 验证，最早 v2 原件还会进入 importProjectV2 和 migrateSceneV2 的严格契约检查。普通当前编辑因此也处理旧完整包。
- ZIP entry read、fflate inflt（Vd）和 CRC32（Ah）均在采样中；仅看 async 外层 Vn 的 inclusive 会漏掉 await 后丢失父栈的工作。ZIP 家族单列，但同样不能与迁移家族直接相加。
- 存储 assertScene / assertContent（Tt/oa）在提交后继续严格场景、身份与外观校验，usageInTransaction 和 save transaction 也有可见采样。保存等待含异步/调度及状态观测，不能把领域后 1506 ms 全称为磁盘时间。

所有 67 个映射均保留精确构建位置（0-based line/column）、函数片段、源码文件和符号；四个 dist JS 的 SHA 与诊断 manifest 一致。当前源码由其他代理修改，报告不把新源码当作本轮 profile 所属构建，也不以源码行号绑定证据。

## CDP/page 对齐边界

主分析使用 profile 阶段资源记录的 NavigationStart=112894.670453 秒：pageMs ≈ cdpUs/1000 − NavigationStart×1000。该桥接得到 profile 页内区间 11342.8–15525.2 ms。Profiler.start 返回后的页标记在估计 profile 起点后约 113.0 ms；不能直接把两者重合。

这不是额外同步 marker。start/stop 控制观测只给出 CDP−page offset 区间，宽 113.7 ms。以下为 NavigationStart 与上下边界三个对齐情景的范围，**不是置信区间**：

| 家族 | 意图 → 领域采样比例范围 | 领域 → 显示代理采样比例范围 |
|---|---:|---:|
| 严格 v2/v3 场景解析（含依赖/几何） | 28.4–30.5% | 33.5–34.4% |
| bounded JSON 解析 | 14.1–14.3% | 10.6–10.9% |
| 外观 resolve（含内部复制） | 1.6–1.8% | 2.5–2.8% |
| 迁移导入可见栈与 ZIP 读取/解压/CRC 的并集 | 42.0–43.9% | 33.0–35.9% |

领域→底图仅 136.5 ms，其 CPU 子窗口分配尤其受对齐误差影响；同页的真实区间长度不受此影响。全部细分窗口与敏感性在 JSON 中。

## 方法与限制

累积每个 timeDelta 并按窗口裁剪；每个函数 location 每个样本至多计一次 inclusive。配置 1000 µs，实际 delta 中位数 1507 µs；profile 共 2679 个样本，完整墙钟 4182.442 ms，采样权重 4182.189 ms，末尾 253 µs 未归属，未擅自补给任一函数。idle/program/GC 保留为 V8 特殊样本，不分给产品代码。

这是 renderer target 的采样，不覆盖所有浏览器进程或 GPU；采样 self/inclusive 是估计值。await 可使异步父栈缺失，调用树节点不等于调用次数，完整 profile 还含 field.fill、arm、自动化/观测等待及 profiler 开销。后续须用无 profiler 的正常 UI 全负载矩阵验证改进及正确性。

原始证据：[result](perf-diagnostic-3/study-500-run-1.json)、[profile](perf-diagnostic-3/study-500-run-1-ordinary-edit-1.cpuprofile)、[manifest](perf-diagnostic-3/manifest.json)。profile SHA256：cf5fbb3a43a72a75bd8f02430892b3104ffa765766513b53522185f7fda6b7ec。
